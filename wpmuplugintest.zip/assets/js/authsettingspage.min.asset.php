<?php return array('dependencies' => array('wp-components', 'wp-element'), 'version' => '2064d67973560c031bd5');
