<?php
/**
 * Plugin Name:       WPMU DEV Plugin Test
 * Description:       A plugin focused on testing coding skills.
 * Requires at least: 6.1
 * Requires PHP:      7.4
 * Version:           1.0.0
 * Author:            Adeniyi, ADEREHINWO
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wpmudev-plugin-test
 *
 * @package           WPMUDEVPluginTest
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define constants.
define( 'WPMUDEV_PLUGINTEST_VERSION', '1.0.0' );
define( 'WPMUDEV_PLUGINTEST_PLUGIN_FILE', __FILE__ );
define( 'WPMUDEV_PLUGINTEST_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPMUDEV_PLUGINTEST_URL', plugin_dir_url( __FILE__ ) );
define( 'WPMUDEV_PLUGINTEST_ASSETS_URL', WPMUDEV_PLUGINTEST_URL . 'assets/' );
define( 'WPMUDEV_PLUGINTEST_SUI_VERSION', '2.12.23' );

// Include the custom autoloader.
require_once plugin_dir_path( __FILE__ ) . 'autoload.php';

/**
 * Main plugin class.
 */
class WPMUDEV_PluginTest {
    /**
     * Holds the class instance.
     *
     * @var WPMUDEV_PluginTest
     */
    private static $instance = null;

    /**
     * Return an instance of the class.
     *
     * @return WPMUDEV_PluginTest
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Class initializer.
     */
    public function load() {
        // Load plugin text domain for translations.
        load_plugin_textdomain(
            'wpmudev-plugin-test',
            false,
            dirname( plugin_basename( __FILE__ ) ) . '/languages'
        );

        // Add admin menu and enqueue scripts.
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

        // Handle AJAX request to save settings.
        add_action( 'wp_ajax_wpmudev_save_auth_settings', array( $this, 'save_auth_settings' ) );
        add_action( 'wp_ajax_wpmudev_scan_posts', array( $this, 'scan_posts' ) );

        // Register REST API routes.
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

        // Register WP-CLI command.
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            WP_CLI::add_command( 'wpmudev scan-posts', array( $this, 'cli_scan_posts' ) );
        }

        // Register shortcodes.
        $this->register_shortcodes();
    }

    /**
     * Adds the admin menu for Google Auth settings.
     */
    public function add_admin_menu() {
        add_menu_page(
            __( 'Google Auth', 'wpmudev-plugin-test' ),
            __( 'Google Auth', 'wpmudev-plugin-test' ),
            'manage_options',
            'wpmudev-google-auth',
            array( $this, 'render_admin_page' ),
            'dashicons-admin-generic'
        );

        add_submenu_page(
            'wpmudev-google-auth',
            __( 'Posts Maintenance', 'wpmudev-plugin-test' ),
            __( 'Posts Maintenance', 'wpmudev-plugin-test' ),
            'manage_options',
            'wpmudev-posts-maintenance',
            array( $this, 'render_posts_maintenance_page' )
        );
    }

    /**
     * Renders the Google Auth settings page.
     */
    public function render_admin_page() {
        ?>
        <div class="wrap">
            <h1><?php _e( 'Google Auth', 'wpmudev-plugin-test' ); ?></h1>
            <form method="post" id="wpmudev-auth-form">
                <?php wp_nonce_field( 'wpmudev_save_auth_settings', 'wpmudev_auth_nonce' ); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php _e( 'Client ID', 'wpmudev-plugin-test' ); ?></th>
                        <td><input type="text" name="wpmudev_client_id" value="<?php echo esc_attr( get_option( 'wpmudev_client_id' ) ); ?>" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e( 'Client Secret', 'wpmudev-plugin-test' ); ?></th>
                        <td><input type="password" name="wpmudev_client_secret" value="<?php echo esc_attr( get_option( 'wpmudev_client_secret' ) ); ?>" /></td>
                    </tr>
                </table>
                <button type="submit" class="button button-primary"><?php _e( 'Save', 'wpmudev-plugin-test' ); ?></button>
            </form>
        </div>
        <?php
    }

    /**
     * Renders the Posts Maintenance page.
     */
    public function render_posts_maintenance_page() {
        ?>
        <div class="wrap">
            <h1><?php _e( 'Posts Maintenance', 'wpmudev-plugin-test' ); ?></h1>
            <button id="scan-posts-button" class="button button-primary"><?php _e( 'Scan Posts', 'wpmudev-plugin-test' ); ?></button>
            <p id="scan-posts-message"></p>
        </div>
        <?php
    }

    /**
     * Enqueues admin scripts.
     */
    public function enqueue_admin_scripts() {
        wp_enqueue_script( 'wpmudev-admin-js', WPMUDEV_PLUGINTEST_ASSETS_URL . 'admin.js', array( 'jquery' ), WPMUDEV_PLUGINTEST_VERSION, true );
        wp_localize_script( 'wpmudev-admin-js', 'wpmudev_admin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpmudev_admin_nonce' ),
        ));
    }

    /**
     * Handles the AJAX request to save Google Auth settings.
     */
    public function save_auth_settings() {
        check_ajax_referer( 'wpmudev_admin_nonce', '_ajax_nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Unauthorized user', 'wpmudev-plugin-test' ) );
        }

        $client_id = sanitize_text_field( $_POST['client_id'] );
        $client_secret = sanitize_text_field( $_POST['client_secret'] );

        update_option( 'wpmudev_client_id', $client_id );
        update_option( 'wpmudev_client_secret', $client_secret );

        wp_send_json_success();
    }

    /**
     * Handles the AJAX request to scan posts.
     */
    public function scan_posts() {
        check_ajax_referer( 'wpmudev_admin_nonce', '_ajax_nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Unauthorized user', 'wpmudev-plugin-test' ) );
        }

        $this->execute_scan_posts();

        wp_send_json_success();
    }

    /**
     * Executes the scan posts action.
     */
    private function execute_scan_posts() {
        $post_types = apply_filters( 'wpmudev_scan_post_types', array( 'post', 'page' ) );

        $query_args = array(
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        );

        $query = new WP_Query( $query_args );

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                update_post_meta( get_the_ID(), 'wpmudev_test_last_scan', current_time( 'timestamp' ) );
            }
        }

        wp_reset_postdata();
    }

    /**
     * Register REST API routes for Google oAuth.
     */
    public function register_rest_routes() {
        register_rest_route( 'wpmudev/v1', '/auth/auth-url', array(
            'methods'  => 'POST',
            'callback' => array( $this, 'save_auth_settings_rest' ),
            'permission_callback' => function() {
                return current_user_can( 'manage_options' );
            }
        ));

        register_rest_route( 'wpmudev/v1', '/auth/confirm', array(
            'methods'  => 'GET',
            'callback' => array( $this, 'handle_oauth_confirm' ),
            'permission_callback' => '__return_true'
        ));
    }

       /**
     * Handle the oAuth confirmation.
     *
     * @param WP_REST_Request $request The REST request.
     * @return WP_REST_Response
     */
    public function handle_oauth_confirm( $request ) {
        $email = $this->get_oauth_email( $request );

        if ( ! email_exists( $email ) ) {
            $user_id = wp_create_user( $email, wp_generate_password(), $email );
        } else {
            $user = get_user_by( 'email', $email );
            $user_id = $user->ID;
        }

        wp_set_auth_cookie( $user_id );

        wp_redirect( admin_url() );
        exit;
    }

    /**
     * Get the oAuth email from the request.
     *
     * @param WP_REST_Request $request The REST request.
     * @return string|null The user's email.
     */
    private function get_oauth_email( $request ) {
        return isset( $request['email'] ) ? sanitize_email( $request['email'] ) : null;
    }

    /**
     * Register the shortcode for Google oAuth login.
     */
    public function register_shortcodes() {
        add_shortcode( 'google_oauth_login', array( $this, 'google_oauth_login_shortcode' ) );
    }

    /**
     * Shortcode to display Google oAuth login link or personalized message.
     *
     * @return string
     */
    public function google_oauth_login_shortcode() {
        if ( is_user_logged_in() ) {
            $user = wp_get_current_user();
            return sprintf( __( 'Hello, %s!', 'wpmudev-plugin-test' ), esc_html( $user->display_name ) );
        } else {
            $auth_url = $this->get_google_oauth_url();
            return sprintf( '<a href="%s">%s</a>', esc_url( $auth_url ), __( 'Login with Google', 'wpmudev-plugin-test' ) );
        }
    }

    /**
     * Get the Google oAuth URL.
     *
     * @return string
     */
    private function get_google_oauth_url() {
        return 'https://accounts.google.com/o/oauth2/auth?scope=email&redirect_uri=' . urlencode( rest_url( 'wpmudev/v1/auth/confirm' ) ) . '&response_type=code&client_id=' . esc_attr( get_option( 'wpmudev_client_id' ) );
    }

    /**
     * WP-CLI command to scan posts.
     *
     * @param array $args
     * @param array $assoc_args
     */
    public function cli_scan_posts( $args, $assoc_args ) {
        $this->execute_scan_posts();
        WP_CLI::success( 'Posts scanned successfully.' );
    }
}

// Initialize the plugin.
add_action( 'plugins_loaded', function () {
    WPMUDEV_PluginTest::get_instance()->load();
});


//autoloader

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

require_once plugin_dir_path( __FILE__ ) . 'autoload.php';

