jQuery(document).ready(function($) {
    // Handle Google Auth settings form submission
    $('#wpmudev-auth-form').on('submit', function(e) {
        e.preventDefault();

        var data = {
            action: 'wpmudev_save_auth_settings',
            client_id: $('input[name="wpmudev_client_id"]').val(),
            client_secret: $('input[name="wpmudev_client_secret"]').val(),
            _ajax_nonce: wpmudev_admin.nonce
        };

        $.post(wpmudev_admin.ajax_url, data, function(response) {
            if (response.success) {
                alert('Settings saved successfully.');
            } else {
                alert('Error saving settings: ' + response.data);
            }
        });
    });

    // Handle Scan Posts button click
    $('#scan-posts-button').on('click', function() {
        var data = {
            action: 'wpmudev_scan_posts',
            _ajax_nonce: wpmudev_admin.nonce
        };

        $('#scan-posts-message').text('Scanning posts...');

        $.post(wpmudev_admin.ajax_url, data, function(response) {
            if (response.success) {
                $('#scan-posts-message').text('Posts scanned successfully.');
            } else {
                $('#scan-posts-message').text('Error scanning posts: ' + response.data);
            }
        });
    });
});
