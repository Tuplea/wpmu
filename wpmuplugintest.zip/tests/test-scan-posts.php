<?php
/**
 * Test case for Scan Posts functionality.
 */
class ScanPostsTest extends WP_UnitTestCase {

    /**
     * Test scanning posts.
     */
    public function test_scan_posts() {
        // Create some test posts.
        $post_ids = $this->factory->post->create_many( 3 );

        // Execute the scan posts action.
        $plugin = WPMUDEV_PluginTest::get_instance();
        $plugin->execute_scan_posts();

        // Check if the 'wpmudev_test_last_scan' post meta was updated for each post.
        foreach ( $post_ids as $post_id ) {
            $last_scan_time = get_post_meta( $post_id, 'wpmudev_test_last_scan', true );
            $this->assertNotEmpty( $last_scan_time, 'Failed to update last scan time for post ID: ' . $post_id );
        }
    }

}
